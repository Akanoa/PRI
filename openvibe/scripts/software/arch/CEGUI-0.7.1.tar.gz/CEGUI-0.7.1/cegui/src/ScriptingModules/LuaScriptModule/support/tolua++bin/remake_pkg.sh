#!/bin/sh
tolua++ -H toluabind.h -o toluabind.c -n tolua tolua_scons.pkg
