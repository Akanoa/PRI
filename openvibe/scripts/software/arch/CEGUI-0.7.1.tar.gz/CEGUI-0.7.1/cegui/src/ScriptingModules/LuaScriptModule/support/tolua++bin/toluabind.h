/*
** Lua binding: tolua
** Generated automatically by tolua++-1.0.92 on Mon Jul 20 10:54:06 2009.
*/

/* Exported function */
int tolua_tolua_open (lua_State* tolua_S);

